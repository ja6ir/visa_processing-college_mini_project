package com.visaprocessing.visaprocessing;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class VisaprocessingApplicationTests {

	@Test
	void contextLoads() {
	}

}
